<?php
/*
Plugin Name: Peepso URL Shortener (Admin Only)
Description: Admin-only URL shortener with analytics and security.
Version: 1.4
Author: Dakota
*/

// Security check
if ( ! defined( 'ABSPATH' ) ) exit;

// Load dependencies
require_once plugin_dir_path( __FILE__ ) . 'includes/shortener.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/admin.php';

// Activation hook
register_activation_hook( __FILE__, 'ps_activate' );

// Deactivation hook
register_deactivation_hook( __FILE__, 'ps_deactivate' );
