<?php
// Require WP_List_Table if not loaded
if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

// Add admin menu
add_action('admin_menu', 'ps_add_admin_menu');
function ps_add_admin_menu() {
    add_menu_page(
        'URL Shortener',
        'URL Shortener',
        'manage_options',
        'peepso-shortener',
        'ps_admin_page',
        'dashicons-admin-links',
        30
    );
}

// Redirect unauthorized users
function ps_admin_page() {
    if ( ! current_user_can('manage_options') ) {
        wp_redirect( wp_login_url( admin_url('admin.php?page=peepso-shortener') ) );
        exit;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'peepso_short_urls';

    $success = '';
    $error = '';

    // Handle form submissions
    if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
        if ( $_POST['action'] === 'add' ) {
            if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'add_peepso_shortener' ) ) {
                $error = 'Security check failed.';
            } else {
                $long_url = esc_url( $_POST['long_url'] );
                
                if ( empty($long_url) ) {
                    $error = 'Please enter a valid URL.';
                } else {
                    $short_code = generate_short_code();
                    
                    // Retry generating code if exists (max 10 attempts)
                    $attempts = 10;
                    while ( $wpdb->get_var( $wpdb->prepare("SELECT short_code FROM $table_name WHERE short_code = %s", $short_code) ) && $attempts > 0 ) {
                        $short_code = generate_short_code();
                        $attempts--;
                    }
                    
                    if ( $attempts <= 0 ) {
                        $error = 'Failed to generate a unique short code.';
                    } else {
                        $wpdb->insert(
                            $table_name,
                            array(
                                'short_code' => $short_code,
                                'long_url' => $long_url,
                                'created_at' => current_time('mysql'),
                                'clicks' => 0,
                                'last_clicked' => null
                            )
                        );
                        $success = 'URL added!';
                    }
                }
            }
        } elseif ( $_POST['action'] === 'edit' ) {
            if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'edit_peepso_shortener' ) ) {
                $error = 'Security check failed.';
            } else {
                $id = absint( $_POST['id'] );
                $long_url = esc_url( $_POST['long_url'] );
                
                if ( empty($long_url) ) {
                    $error = 'Please enter a valid URL.';
                } else {
                    $wpdb->update(
                        $table_name,
                        array( 'long_url' => $long_url ),
                        array( 'id' => $id )
                    );
                    $success = 'URL updated!';
                    wp_redirect( admin_url('admin.php?page=peepso-shortener') );
                    exit;
                }
            }
        }
    }

    // Handle deletions
    if ( isset($_GET['action']) && $_GET['action'] === 'delete' ) {
        $id = absint( $_GET['id'] );
        $nonce = $_GET['_wpnonce'];

        if ( ! wp_verify_nonce( $nonce, 'delete_peepso_shortener-'.$id ) ) {
            $error = 'Security check failed.';
        } else {
            $wpdb->delete( $table_name, array('id' => $id) );
            $success = 'URL deleted!';
            wp_redirect( admin_url('admin.php?page=peepso-shortener') );
            exit;
        }
    }

    // Render the admin page
    ?>
    <div class="wrap">
        <h1>URL Shortener</h1>
        <?php
        if ( isset($success) ) echo '<div class="notice notice-success is-dismissible"><p>'.$success.'</p></div>';
        if ( isset($error) ) echo '<div class="notice notice-error is-dismissible"><p>'.$error.'</p></div>';
        ?>

        <!-- Add New URL Form -->
        <h2>Add New URL</h2>
        <form class="add-url-form" method="post">
            <?php wp_nonce_field('add_peepso_shortener', '_wpnonce'); ?>
            <input type="hidden" name="action" value="add">
            
            <label for="long_url_input">Enter URL</label>
            <input 
                type="text" 
                id="long_url_input" 
                name="long_url" 
                placeholder="Enter URL" 
                required
            >
            <button type="submit" class="button button-primary">Shorten</button>
        </form>

        <!-- Edit Form (if editing) -->
        <?php
        if ( isset($_GET['action']) && $_GET['action'] === 'edit' ) {
            $id = absint( $_GET['id'] );
            $entry = $wpdb->get_row( $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id) );
            if ( $entry ) {
                ?>
                <h2>Edit URL</h2>
                <form class="add-url-form" method="post">
                    <?php wp_nonce_field('edit_peepso_shortener', '_wpnonce'); ?>
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    
                    <label for="long_url_edit">Enter URL</label>
                    <input 
                        type="text" 
                        id="long_url_edit" 
                        name="long_url" 
                        value="<?php echo esc_attr($entry->long_url); ?>" 
                        required
                    >
                    <button type="submit" class="button button-primary">Update</button>
                </form>
                <?php
            }
        }
        ?>

        <!-- List Table -->
        <h2>Existing URLs</h2>
        <?php
        $list_table = new PeepsoShortener_List_Table();
        $list_table->prepare_items();
        $list_table->display();
        ?>
    </div>
    <?php
}


// Enqueue admin CSS
add_action('admin_enqueue_scripts', 'ps_enqueue_styles');
function ps_enqueue_styles() {
    wp_enqueue_style('ps-shortener-style', plugins_url('includes/admin.css', __FILE__));
}

class PeepsoShortener_List_Table extends WP_List_Table {
    function __construct() {
        parent::__construct( array(
            'singular' => 'shortener_entry',
            'plural' => 'shortener_entries',
            'ajax' => false
        ) );
    }

    // Define table columns
    function get_columns() {
        return array(
            'short_code' => 'Short Code',
            'long_url' => 'Long URL',
            'created_at' => 'Created',
            'clicks' => 'Clicks',
            'last_clicked' => 'Last Clicked',
            'actions' => 'Actions'
        );
    }

    // Prepare items with pagination and column setup
    function prepare_items() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'peepso_short_urls';

        // === Step 1: Pagination Setup ===
        $per_page = 10; // Items per page
        $current_page = $this->get_pagenum(); // Current page number
        $offset = ($current_page - 1) * $per_page;

        // === Step 2: Fetch Data with Pagination ===
        $sql = $wpdb->prepare(
            "SELECT * FROM $table_name ORDER BY created_at DESC LIMIT %d OFFSET %d",
            $per_page,
            $offset
        );
        $this->items = $wpdb->get_results($sql);

        // === Step 3: Get Total Items for Pagination ===
        $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");

        // === Step 4: Set Pagination Arguments ===
        $this->set_pagination_args( array(
            'total_items' => $total_items,
            'per_page' => $per_page,
        ) );

        // === Step 5: Define Columns and Headers ===
        $columns = $this->get_columns(); // Get all columns
        $hidden = array(); // No hidden columns
        $sortable = array('created_at' => array('created_at', true)); // Add sortable columns
        $this->_column_headers = array($columns, $hidden, $sortable); // Critical fix!
    }

    // Render individual columns
    function column_default( $item, $column_name ) {
        switch( $column_name ) {
            case 'short_code':
                return '<a href="'.site_url('/s/'.$item->short_code).'">'.$item->short_code.'</a>';
            case 'long_url':
                return $item->long_url;
            case 'created_at':
                return date_i18n('Y-m-d H:i', strtotime($item->created_at));
            case 'clicks':
                return $item->clicks;
            case 'last_clicked':
                return $item->last_clicked ? date_i18n('Y-m-d H:i', strtotime($item->last_clicked)) : 'Never';
            case 'actions':
                $actions = array(
                    'edit' => sprintf('<a href="?page=peepso-shortener&action=edit&id=%d">Edit</a>', $item->id),
                    'delete' => sprintf('<a class="submitdelete" href="?page=peepso-shortener&action=delete&id=%d&_wpnonce=%s">Delete</a>',
                        $item->id,
                        wp_create_nonce('delete_peepso_shortener-'.$item->id)
                    )
                );
                return $this->row_actions($actions);
            default:
                return print_r( $item, true ); // Debug fallback
        }
    }

    // Optional: Add sortable columns
    function sort_link( $column, $args = array() ) {
        return '<a href="?page=peepso-shortener&orderby='.$column.'&order='.esc_attr( empty( $_GET['order'] ) ? 'asc' : $_GET['order'] ).'">'.$args['text'].'</a>';
    }
}
