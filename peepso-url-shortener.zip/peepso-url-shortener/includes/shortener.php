<?php
global $wpdb;

// Activation: Create database table
function ps_activate() {
    create_shortener_table();
    flush_rewrite_rules();
}


// Deactivation: Flush rewrite rules
function ps_deactivate() {
    flush_rewrite_rules();
}

// Create database table
function create_shortener_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'peepso_short_urls'; // Define HERE
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        short_code varchar(255) NOT NULL,
        long_url longtext NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        clicks int NOT NULL DEFAULT 0,
        last_clicked datetime DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY short_code (short_code)
    ) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}

// Add rewrite rule for short URLs
add_action('init', 'ps_add_rewrite_rules');
function ps_add_rewrite_rules() {
    add_rewrite_rule(
        '^s/([^/]*)/?',
        'index.php?short_code=$matches[1]',
        'top'
    );
}

// Handle redirects
add_filter('query_vars', 'ps_add_query_vars');
function ps_add_query_vars($vars) {
    $vars[] = 'short_code';
    return $vars;
}

add_action('template_redirect', 'ps_redirect_short_url');
function ps_redirect_short_url() {
    global $wp_query, $wpdb;
    $short_code = $wp_query->get('short_code');

    if ( $short_code ) {
        $table_name = $wpdb->prefix . 'peepso_short_urls';
        $url = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE short_code = %s",
                $short_code
            )
        );

        if ( $url ) {
            // Update click count and last clicked time
            $wpdb->update(
                $table_name,
                array(
                    'clicks' => $url->clicks + 1,
                    'last_clicked' => current_time('mysql')
                ),
                array( 'id' => $url->id )
            );
            
            // Permanent redirect (301)
            wp_redirect( esc_url( $url->long_url ), 301 );
            exit;
        }
    }
}

// Short code generator with loop limit
function generate_short_code($length = 6, $attempts = 1000) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $code = '';
    
    do {
        $code = '';
        for ($i = 0; $i < $length; $i++) {
            $code .= $chars[rand(0, strlen($chars) - 1)];
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'peepso_short_urls';
        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT short_code FROM $table_name WHERE short_code = %s",
                $code
            )
        );
        
        $attempts--;
    } while ( $exists && $attempts > 0 );
    
    return $code;
}
